package ex2.ex2_1;

public interface MyList {
    abstract void add(Object o, int index);

    abstract void remove(int index);

    abstract int size();

    abstract Object get(int index);

    abstract void add(Object o);

}
